package Lesson8.Problem2;

public interface EmployeeData {
    double getSalary();

}
