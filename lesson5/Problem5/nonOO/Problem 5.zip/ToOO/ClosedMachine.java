package lesson5.Problem5.nonOO.ToOO;

abstract public class ClosedMachine {
    abstract void performFunction();
}
